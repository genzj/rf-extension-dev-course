# encoding: utf-8
from ..util import to_num

ROBOT_LIBRARY_VERSION = '1.0'


def add(n1, n2=1):
    return to_num(n1) + to_num(n2)

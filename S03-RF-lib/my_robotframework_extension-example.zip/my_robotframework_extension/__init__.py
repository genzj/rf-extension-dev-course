"""Top-level package for My RobotFramework Extension."""

__author__ = """Jie"""
__email__ = 'zj0512@gmail.com'
__version__ = '0.1.0'

from .keywords import MyAdd, MyClassAdd


my_robotframework_extension = MyClassAdd.MyClassAdd

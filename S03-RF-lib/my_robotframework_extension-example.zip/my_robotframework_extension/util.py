
def to_num(n):
    return float(n) if '.' in str(n) else int(n)

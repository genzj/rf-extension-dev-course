=====
Usage
=====

To use My RobotFramework Extension in a project::

    import my_robotframework_extension

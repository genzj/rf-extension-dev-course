#!/usr/bin/env python

"""Tests for `my_robotframework_extension` package."""


import unittest

from my_robotframework_extension import my_robotframework_extension


class TestMy_robotframework_extension(unittest.TestCase):
    """Tests for `my_robotframework_extension` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""

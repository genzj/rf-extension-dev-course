=======
History
=======

0.1.0 (2020-12-25)
------------------

* First release on PyPI.
